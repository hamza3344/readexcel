﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace readexcel
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Excel.Application xlApp;
            Excel.Workbook xlworkBook;
            Excel.Worksheet xlworkSheet;
            Excel.Range range;
            int rCnt = 0;
            int cCnt = 0;
            xlApp = new Excel.Application();
            xlworkBook = xlApp.Workbooks.Open("C:\\sample\\2test.xlsx", 0, true, 5, "", "",
                true, Excel.XlPlatform.xlWindows, "\t", false, false, 0, true, 1, 0);
            xlworkSheet = (Excel.Worksheet)xlworkBook.Worksheets.get_Item(1);
            range = xlworkSheet.UsedRange;
            //get formula
            for(rCnt=1;rCnt<=range.Rows.Count;rCnt++)
            {
                for(cCnt=1;cCnt<=range.Columns.Count;cCnt++)
                {
                    if(!(((range.Cells[rCnt,cCnt] as Excel.Range).Formula)==null) && range.Cells[rCnt,cCnt]!=null)
                        {
                        string d1 = (range.Cells[rCnt, cCnt] as Excel.Range).Formula;
                        if(d1.StartsWith("=") && d1!!="")
                        {
                            MessageBox.Show("formuala="+d1);
                        }
                    }
                }
            }
            for (rCnt = 1; rCnt <= range.Rows.Count; rCnt++)
            {
                for (cCnt = 1; cCnt <= range.Columns.Count; cCnt++)
                {
                    string d1 = Convert.ToString((range.Cells[rCnt, cCnt] as Excel.Range).Value2);
                    MessageBox.Show(d1);
                }
            }
            xlApp.Quit();
            ReleaseObject(xlworkSheet);
            ReleaseObject(xlworkBook);
            ReleaseObject(xlApp);
        }
        private void ReleaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch(Exception)
            {
                obj = null;
            }
            finally
            {
                GC.Collect();
            }
        }
        
    }
}
